# Backend – Flask API (Better Assessment)

This folder contains the backend implementation for the Better assessment using **Flask**.

---

##  Tech Stack
- Python
- Flask
- Flask-SQLAlchemy
- SQLite
- Pytest

---

##  Features
- RESTful CRUD APIs for comments
- SQLite database for persistence
- Modular project structure
- Automated tests using pytest

---

##  Project Structure
