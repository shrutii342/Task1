from flask import Blueprint, request, jsonify
from database import db
from models import Comment

routes = Blueprint('routes', __name__)

@routes.route('/comments', methods=['POST'])
def add_comment():
    data = request.json
    comment = Comment(text=data['text'], task_id=data['task_id'])
    db.session.add(comment)
    db.session.commit()
    return jsonify({"message": "Comment added"}), 201

@routes.route('/comments/<int:id>', methods=['PUT'])
def update_comment(id):
    comment = Comment.query.get_or_404(id)
    comment.text = request.json['text']
    db.session.commit()
    return jsonify({"message": "Comment updated"})

@routes.route('/comments/<int:id>', methods=['DELETE'])
def delete_comment(id):
    comment = Comment.query.get_or_404(id)
    db.session.delete(comment)
    db.session.commit()
    return jsonify({"message": "Comment deleted"})

@routes.route('/comments', methods=['GET'])
def get_comments():
    comments = Comment.query.all()
    return jsonify([
        {"id": c.id, "text": c.text, "task_id": c.task_id}
        for c in comments
    ])
