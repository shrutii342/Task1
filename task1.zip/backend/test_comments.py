from app import app
import json

def test_add_comment():
    client = app.test_client()
    response = client.post('/comments',
        json={"text": "Test comment", "task_id": 1}
    )
    assert response.status_code == 201
